package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class EmployeeHobby 
{
	@Id
	@Column
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int hid;
	@Column
	private String hname;
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="eid")
	private Employee employee;
	
	public EmployeeHobby()
	{
		
	}
	public EmployeeHobby(String hname) {
		super();
		this.hname = hname;
	}
	public int getHid() {
		return hid;
	}
	public void setHid(int hid) {
		this.hid = hid;
	}
	public String getHname() {
		return hname;
	}
	public void setHname(String hname) {
		this.hname = hname;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	@Override
	public String toString() {
		return "EmployeeHobby [hid=" + hid + ", hname=" + hname + ", employee=" + employee + "]".toString();
	}
	
	
}