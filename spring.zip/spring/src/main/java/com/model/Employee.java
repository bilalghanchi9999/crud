package com.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="employee")
public class Employee 
{
	@Id
	@Column
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int eid;
	@Column
	private String ename;
	@Column
	private int salary;
	@Column
	private String gender;
	@OneToMany(mappedBy="employee",fetch=FetchType.EAGER)
	private List<EmployeeHobby> employeehobby;
	@OneToMany(mappedBy="employee",fetch=FetchType.LAZY)
	private List<EmployeeSkill> employeeskill;
	
	public Employee() {

	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public List<EmployeeHobby> getEmployeehobby() {
		return employeehobby;
	}
	public void setEmployeehobby(List<EmployeeHobby> employeehobby) {
		this.employeehobby = employeehobby;
	}
	public List<EmployeeSkill> getEmployeeskill() {
		return employeeskill;
	}
	public void setEmployeeskill(List<EmployeeSkill> employeeskill) {
		this.employeeskill = employeeskill;
	}
	
}