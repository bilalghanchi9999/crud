package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class EmployeeSkill 
{
	@Id
	@Column
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int sid;
	@Column
	private String sname;
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="eid")
	private Employee employee;
	
	public EmployeeSkill() {
	}
	
	public EmployeeSkill(String sname) {
		super();
		this.sname = sname;
	}

	public EmployeeSkill(int sid, String sname, Employee employee) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.employee = employee;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
}