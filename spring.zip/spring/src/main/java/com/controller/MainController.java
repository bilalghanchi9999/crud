package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Employee;
import com.model.EmployeeHobby;
import com.model.EmployeeSkill;
import com.service.EmployeeHobbyService;
import com.service.EmployeeService;
import com.service.EmployeeSkillService;

@Controller
public class MainController 
{
	@Autowired
	 EmployeeService employeeService;
	@Autowired
	EmployeeHobbyService employeeHobbyService;
	@Autowired
	EmployeeSkillService employeeSkillService;
	
	public List<EmployeeHobby> getEmployeeHobby()
	{
		List<EmployeeHobby> hobby= new ArrayList<>();
		hobby.add(new EmployeeHobby("cricket"));
		hobby.add(new EmployeeHobby("hockey"));
		hobby.add(new EmployeeHobby("football"));
		hobby.add(new EmployeeHobby("vollyball"));
		return hobby;
	}
	public List<EmployeeSkill> getEmployeeSkill()
	{
		List<EmployeeSkill> skills=new ArrayList<>();
		skills.add(new EmployeeSkill("C"));
		skills.add(new EmployeeSkill("C++"));
		skills.add(new EmployeeSkill("JAVA"));
		skills.add(new EmployeeSkill("PHP"));
		skills.add(new EmployeeSkill(".NET"));
		return skills;
	}
	
	@RequestMapping(value="/")
	public ModelAndView getHome(ModelAndView model)
	{
		List<Employee> employess=employeeService.getAllEmployee();
		List<EmployeeHobby> hobbies=employeeHobbyService.getAllHobby();
		List<EmployeeSkill> skills=employeeSkillService.getAllSkill();
		model.addObject("employess", employess);
		model.addObject("hobbies", hobbies);
		model.addObject("skills",skills);
		model.setViewName("home");
		return model;
	}
	@RequestMapping(value="/newEmployee",method = RequestMethod.GET)
	public ModelAndView newEmployee(ModelAndView model)
	{	
			/*for Employee hobby checkbox*/
		List<EmployeeHobby> hobby= getEmployeeHobby();
			/*for Employee Skills listbox*/
		List<EmployeeSkill> skill=getEmployeeSkill();
			/*for Employee Country dropdown*/
		model.addObject("hobby",hobby);
		model.addObject("skill",skill);
		Employee employee = new Employee();
		model.addObject("employee",employee);
		model.setViewName("EmployeeForm");
		return model;
	}
	@RequestMapping(value="/editEmployee")
	public ModelAndView editEmployee(HttpServletRequest req)
	{
		ModelAndView model=new ModelAndView("EmployeeForm");
			int eid=Integer.parseInt(req.getParameter("eid"));
			Employee employee=employeeService.getEmployeeById(eid);
			List<EmployeeHobby> hobby= getEmployeeHobby();
			List<EmployeeSkill> skill=getEmployeeSkill();
			
			List<EmployeeSkill> empskill=employeeSkillService.getSkillsForEmployee(eid);
			List<EmployeeHobby> emphobby=employeeHobbyService.getHobbiesForEmployee(eid);
			employee.setEmployeeskill(empskill);
			model.addObject("hobby",hobby);
			model.addObject("skill",skill);
			model.addObject("employee", employee);
			model.addObject("emphobby",emphobby);
			model.addObject("empskill", empskill);
			return model;
	}
	@RequestMapping(value="/saveEmployee",method=RequestMethod.POST)
	public ModelAndView saveEmployee(@ModelAttribute Employee employee)
	{
		ModelAndView model=new ModelAndView();
/*		System.out.println(employee.toString());*/
		List<EmployeeHobby> hobby=employee.getEmployeehobby();
		List<EmployeeSkill> skills=employee.getEmployeeskill();
		/*System.out.println(hobby);*/
		for(EmployeeHobby h:hobby)
			h.setEmployee(employee);
		
		for(EmployeeSkill s:skills)
			s.setEmployee(employee);
		
		if(employee.getEid()==0)
		{
			employeeService.insertEmployee(employee);
			employeeHobbyService.insertHobbies(hobby);
			employeeSkillService.insertSkills(skills);
		}
		else
		{
			employeeService.updateEmployee(employee);
			employeeHobbyService.updateHobbies(hobby, employee.getEid());
			employeeSkillService.updateSkills(skills,employee.getEid() );
		}
		model.setViewName("redirect:/");
		return model;
	}
	@RequestMapping("/deleteEmployee")
	public ModelAndView deleteEmployee(HttpServletRequest req)
	{
		ModelAndView model=new ModelAndView();
		int eid=Integer.parseInt(req.getParameter("eid"));
		employeeService.deleteEmployee(eid);
		model.setViewName("redirect:/");
		return model;
	}
	@RequestMapping(value="/searchEmployee",method = RequestMethod.GET)
	public ModelAndView searchEmployee(ModelAndView model)
	{
		Employee e=new Employee();
		List<EmployeeHobby> hobby=getEmployeeHobby();
		List<EmployeeSkill> skill=getEmployeeSkill();
		model.addObject("hobby", hobby);
		model.addObject("skill", skill);
		model.addObject("employee", e);
		model.setViewName("srch");
		return model;
	}
	@RequestMapping(value="/search",method=RequestMethod.POST)
	public ModelAndView searchResult(@ModelAttribute Employee employee)
	{
		ModelAndView model=new ModelAndView("srch");
		List<EmployeeHobby> hobby=getEmployeeHobby();
		List<EmployeeSkill> skill=getEmployeeSkill();
		model.addObject("hobby", hobby);
		model.addObject("skill", skill);
		List<Employee> list=employeeService.searchByEmployee(employee);
		model.addObject("listEmployee", list);
		return model;
	}
}