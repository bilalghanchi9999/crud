package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.Employee;
import com.model.EmployeeHobby;

@Repository
public class EmployeeHobbyDaoImpl implements EmployeeHobbyDao {

	@Autowired
	SessionFactory sesssionFactory;
	
	public void insertHobbies(List<EmployeeHobby> hobbieslist) {
		for(EmployeeHobby h: hobbieslist)
		{
			sesssionFactory.getCurrentSession().save(h);
		}
		this.sesssionFactory.close();
	}

	@SuppressWarnings("unchecked")
	public List<EmployeeHobby> getHobbiesForEmployee(int eid) {
		List<EmployeeHobby> hobb=sesssionFactory.getCurrentSession().createQuery("select e from EmployeeHobby e join fetch e.employee where e.employee=:emp").setParameter("emp",(Employee)sesssionFactory.getCurrentSession().load(Employee.class, eid)).list();
		this.sesssionFactory.close();
		return hobb;
	}

	@SuppressWarnings({ "unused", "unchecked" })
	public void updateHobbies(List<EmployeeHobby> hobbieslist,int eid) {
		Employee e=(Employee)sesssionFactory.getCurrentSession().load(Employee.class, eid);
		List<EmployeeHobby> eh=sesssionFactory.getCurrentSession().createQuery("from EmployeeHobby where employee=:emp").setParameter("emp", e).list();
		for(EmployeeHobby h:eh)
		{
			this.sesssionFactory.getCurrentSession().delete(h);
		}
		for(EmployeeHobby h:hobbieslist)
		{
			sesssionFactory.getCurrentSession().save(h);
		}
		this.sesssionFactory.close();
	}

	@SuppressWarnings("unchecked")
	public List<EmployeeHobby> getAllHobby() {
		List<EmployeeHobby> h=sesssionFactory.getCurrentSession().createQuery("from EmployeeHobby").list();
		this.sesssionFactory.close();
		return h;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmployeeHobby> getHobbyFromObject(Employee e) {
		return this.sesssionFactory.getCurrentSession().createQuery("from EmployeeHobby where employee=:emp").setParameter("emp", e).list();
	}

}