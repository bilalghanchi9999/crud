package com.dao;

import java.util.List;

import com.model.Employee;
import com.model.EmployeeHobby;

public interface EmployeeHobbyDao 
{
	public void insertHobbies(List<EmployeeHobby> hobbieslist);
	public List<EmployeeHobby> getHobbiesForEmployee(int eid);
	public List<EmployeeHobby> getAllHobby();
	public void updateHobbies(List<EmployeeHobby> hobbieslist,int eid);
	public List<EmployeeHobby> getHobbyFromObject(Employee e);
}