package com.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.model.Employee;
import com.model.EmployeeHobby;
import com.model.EmployeeSkill;
import com.service.EmployeeHobbyService;
import com.service.EmployeeSkillService;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{

	@Autowired
	SessionFactory sessionFactory;
	@Autowired
	EmployeeHobbyService employeeHobbyService;
	@Autowired
	EmployeeSkillService employeeSkillService;
	
	@Transactional
	public void insertEmployee(Employee employee) {
		sessionFactory.getCurrentSession().save(employee);
		this.sessionFactory.close();
	}

	@Transactional
	public Employee getEmployeeById(int eid) {
		Employee e=(Employee) sessionFactory.getCurrentSession().get(Employee.class,eid);
		this.sessionFactory.close();
		return e;
	}

	@SuppressWarnings("unchecked")
	
	@Transactional
	public List<Employee> getAllEmployee() {
		List<Employee> em=sessionFactory.getCurrentSession().createQuery(" from Employee").list();
		this.sessionFactory.close();
		return em;
	}

	
	@Transactional
	public Employee updateEmployee(Employee employee) {
		sessionFactory.getCurrentSession().update(employee);
		this.sessionFactory.close();
		return employee;
	}

	@SuppressWarnings({ "unused", "unchecked" })
	@Transactional
	public void deleteEmployee(int eid) {
		Employee emp=(Employee)sessionFactory.getCurrentSession().load(Employee.class, eid);
		
		List<EmployeeHobby> eh=sessionFactory.getCurrentSession().createQuery("from EmployeeHobby where employee=:emp").setParameter("emp", emp).list();
		for(EmployeeHobby h:eh)
			this.sessionFactory.getCurrentSession().delete(h);
			
		List<EmployeeSkill> es=sessionFactory.getCurrentSession().createQuery("from EmployeeSkill where employee=:emp").setParameter("emp",emp).list();
		for(EmployeeSkill s:es)
				this.sessionFactory.getCurrentSession().delete(s);
		
		this.sessionFactory.getCurrentSession().delete(emp);
		this.sessionFactory.close();
	}
	 @SuppressWarnings("unchecked")
	@Transactional
	 private List<Employee> getEmployee(Employee employee)
	 {
		 StringBuffer qry=new StringBuffer();
			int flag=0;
			qry.append("from Employee ");
			if(employee.getEid() != 0 && flag == 0)
			{	
				flag=1;
				qry.append(" where eid=:eid ");
			}
			else if(employee.getEid() != 0 && flag == 1)
			{
				flag=1;
				qry.append(" and eid=:eid");
			}
			if(employee.getEname() != "" && flag == 1)
			{	
				qry.append(" and ename=:ename ");
			}
			else if(employee.getEname() != ""  && flag == 0)
			{
				flag=1;
				qry.append(" where ename = :ename ");
			}
			if(employee.getSalary() != 0 && flag ==1)
			{	
				qry.append(" and salary=:salary ");
			}
			else if(employee.getSalary() !=0 && flag == 0)
			{
				flag=1;
				qry.append(" where salary=:salary ");
			}
			if(employee.getGender() != null && flag ==1)
			{
				qry.append(" and gender=:gender ");
			}
			else if(employee.getGender() != null && flag == 0)
			{
				flag=1;
				qry.append(" where gender = :gender ");
			}
			if(employee.getEmployeehobby() != null && flag==1)
			{
				qry.append("and employeehobby = :employeehobby");
			}
			else if(employee.getEmployeehobby() != null && flag==0)
			{
				flag=1;
				qry.append("where employeehobby = :employeehobby");
			}
			/*if(employee.getEmployeehobby() != null && flag !=0)
			{
				flag=1;
				qry.append(" and employeehobby in (:hobbylist)");
			}
			*/
			System.out.println(qry.toString());
		Query q= this.sessionFactory.getCurrentSession().createQuery(qry.toString());
		if(employee.getEid() != 0)
			q.setParameter("eid", employee.getEid());
		if(employee.getEname() != "")	
			q.setParameter("ename", employee.getEname());
		if(employee.getSalary() != 0)	
			q.setParameter("salary", employee.getSalary());
		if(employee.getGender() != null)
			q.setParameter("gender", employee.getGender());
		if(employee.getEmployeehobby() != null)
			q.setParameterList("employeehobby", employee.getEmployeehobby());
		
		List<Employee> list=q.list();
		 return list;
	 }
	@Override
	@Transactional
	public List<Employee> searchByEmployee(Employee employee) {
		
		List<Employee> employees=getEmployee(employee);
		for(Employee emp:employees)
		{
			emp.setEmployeehobby(employeeHobbyService.getHobbiesForEmployee(emp.getEid()));
			emp.setEmployeeskill(employeeSkillService.getSkillsForEmployee(emp.getEid()));
		}
		return employees;
	}

}