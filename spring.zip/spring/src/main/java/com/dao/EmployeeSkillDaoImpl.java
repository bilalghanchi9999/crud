package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.Employee;
import com.model.EmployeeSkill;

@Repository
public class EmployeeSkillDaoImpl implements EmployeeSkillDao {

	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public void insertSkills(List<EmployeeSkill> skilllist) {
		for(EmployeeSkill es:skilllist)
		{
			sessionFactory.getCurrentSession().save(es);
		}
		this.sessionFactory.close();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmployeeSkill> getSkillsForEmployee(int eid) {
		Employee e=(Employee) sessionFactory.getCurrentSession().load(Employee.class,eid);
		List<EmployeeSkill> skill=sessionFactory.getCurrentSession().createQuery("from EmployeeSkill where employee=:emp").setParameter("emp",e).list();
		this.sessionFactory.close();
		return skill;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmployeeSkill> getAllSkill() {
		List<EmployeeSkill> sk=sessionFactory.getCurrentSession().createQuery("from EmployeeSkill").list();
		this.sessionFactory.close();
		return sk;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void updateSkills(List<EmployeeSkill> skillslist, int eid) {
		Employee e=(Employee) sessionFactory.getCurrentSession().load(Employee.class, eid);
		List<EmployeeSkill> es=this.sessionFactory.getCurrentSession().createQuery("from EmployeeSkill where employee=:e").setParameter("e", e).list();
		for(EmployeeSkill es1:es)
		{
			this.sessionFactory.getCurrentSession().delete(es1);
		}
		for(EmployeeSkill es1:skillslist)
		{
			this.sessionFactory.getCurrentSession().save(es1);
		}
		this.sessionFactory.close();
	}

}