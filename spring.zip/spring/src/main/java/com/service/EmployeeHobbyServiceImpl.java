package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.EmployeeHobbyDao;
import com.model.Employee;
import com.model.EmployeeHobby;

@Service
@Transactional
public class EmployeeHobbyServiceImpl implements EmployeeHobbyService {

	@Autowired
	EmployeeHobbyDao employeeHobbyDao;
	
	@Transactional
	public void insertHobbies(List<EmployeeHobby> hobbieslist) {
		employeeHobbyDao.insertHobbies(hobbieslist);	
		
	}
	@Transactional
	public List<EmployeeHobby> getHobbiesForEmployee(int eid) {
		return employeeHobbyDao.getHobbiesForEmployee(eid);
	}
	@Transactional
	public void updateHobbies(List<EmployeeHobby> hobbieslist, int eid) {
		employeeHobbyDao.updateHobbies(hobbieslist, eid);
	}
	@Transactional
	public List<EmployeeHobby> getAllHobby() {
		return employeeHobbyDao.getAllHobby();
	}
	@Override
	@Transactional
	public List<EmployeeHobby> getHobbyFromObject(Employee e) {
		return employeeHobbyDao.getHobbyFromObject(e);
	}

}