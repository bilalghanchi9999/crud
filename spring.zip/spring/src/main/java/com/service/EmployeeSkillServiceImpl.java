package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.EmployeeSkillDao;
import com.model.EmployeeSkill;

@Service
@Transactional
public class EmployeeSkillServiceImpl implements EmployeeSkillService{

	@Autowired
	EmployeeSkillDao employeeSkillDao;
	
	@Override
	@Transactional
	public void insertSkills(List<EmployeeSkill> skilllist) {
		employeeSkillDao.insertSkills(skilllist);
	}

	@Override
	@Transactional
	public List<EmployeeSkill> getSkillsForEmployee(int eid) {
		return employeeSkillDao.getSkillsForEmployee(eid);
	}

	@Override
	@Transactional
	public List<EmployeeSkill> getAllSkill() {
		return employeeSkillDao.getAllSkill();
	}

	@Override
	@Transactional
	public void updateSkills(List<EmployeeSkill> skillslist, int eid) {
		employeeSkillDao.updateSkills(skillslist, eid);
	}
}