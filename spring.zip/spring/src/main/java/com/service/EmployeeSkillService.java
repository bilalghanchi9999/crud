package com.service;

import java.util.List;

import com.model.EmployeeSkill;

public interface EmployeeSkillService 
{
	public void insertSkills(List<EmployeeSkill> skilllist);
	public List<EmployeeSkill> getSkillsForEmployee(int eid);
	public List<EmployeeSkill> getAllSkill();
	public void updateSkills(List<EmployeeSkill> skillslist,int eid);
}